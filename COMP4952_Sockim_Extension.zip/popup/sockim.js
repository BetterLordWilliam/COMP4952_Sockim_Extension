function onButtonClick(e) {
    e.preventDefault();
    console.log("We are gaming now");
}

// let iframe = document.getElementById("frame");

// window.addEventListener('resize', () => {
//     console.log('life is changing');
//     iframe.style.width = window.innerWidth + 'px';
//     iframe.style.height = window.innerHeight + 'px';
// })
